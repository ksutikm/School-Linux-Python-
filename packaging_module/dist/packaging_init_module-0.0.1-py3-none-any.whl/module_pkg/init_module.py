def init_int(string):
    return int(input(string))


def init_float(string):
    return float(input(string))
